// ===================== APP STATE =====================
// AppState is defined in js/models/appState.js and loaded before this script.

// ===================== HEADER + ACTION BAR =====================
function updateHeader() {
  var sub = document.getElementById('eventSubtitle');
  var tag = document.getElementById('sportTag');
  
  if (AppState.view === 'home' || AppState.ui.showingResults) {
    if (sub) sub.classList.add('hidden');
    if (tag) tag.classList.add('hidden');
  } else if (AppState.view === 'event') {
    if (sub) {
      sub.textContent = AppState.event;
      sub.classList.remove('hidden');
    }
    if (tag) tag.classList.add('hidden');
  } else {
    if (sub) {
      sub.textContent = AppState.event;
      sub.classList.remove('hidden');
    }
    if (tag) {
      tag.textContent = getSportLabel(AppState.sport);
      tag.classList.remove('hidden');
    }
  }
}


function renderActionBar() {
  var bar = document.getElementById('actionBar');
  if (!bar) return;
  var title = document.getElementById('stageTitle');
  var right = document.getElementById('actionBarRight');
  if (!title || !right) return;
  var titles = { setup: 'Setup', groups: 'Group Allocation', fixtures: 'Group Stage Matches', knockout: 'Knockout Stage', champion: '🏆 Champion' };
  title.textContent = titles[AppState.view] || 'Tournament';
  right.innerHTML = '';
  if (AppState.view === 'knockout') {
    right.innerHTML = '<button id="actionBarShowResults" class="btn btn-secondary btn-sm hidden admin-only" onclick="showResults()" style="margin-left:4px;">📊 Results</button>'
      + '<button id="actionBarViewChampion" class="btn btn-secondary btn-sm hidden" data-public="1" onclick="viewChampion()" style="margin-left:4px;">🏆 Champion</button>';
  }
}
// ===================== SAVE (orchestrates storage) =====================
function saveState() {
  if (!AppState.category) return;
  AppState.tournament._lastSave = Date.now();
  AppState.tournament.updatedAt = AppState.tournament._lastSave;
  localSave(AppState.category, AppState.tournament);
  if (isAdmin() && AppState.tournament.phase !== 'setup') {
    scheduleCloudSave(AppState.category, AppState.tournament);
  }
}

// ===================== RENDER CYCLE =====================
// ===================== HOME PAGE =====================
function goHome() {
  navigateTo('home');
}

function sportLabel(s) { return getSportLabel(s); }

function renderHomePage() {
  clearDisabled();
  updateHeader();
  updateNavigationVisibility();
  const events = getEvents();
  const container = document.getElementById('homeContent');
  let html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">'
    + '<h2 class="page-title" style="margin:0;">Events</h2>'
    + (isAdmin() ? '<button class="btn btn-sm btn-secondary" onclick="createEventFromHome()">➕ New Event</button>' : '')
    + '</div>'
    + '<div class="home-events-list">';
  for (const ev of events) {
    const cats = getCategories().filter(c => c.event === ev.name);
    let active = 0;
    for (const c of cats) {
      const st = localLoad(c.id);
      if (st && st.phase !== 'setup') active++;
    }
    const total = cats.length;
    html += '<div class="event-card" onclick="goToEventPage(\'' + escapeHtml(ev.name) + '\')">'
      + '<div class="event-icon">🏆</div>'
      + '<div class="event-info">'
      + '<div class="name">' + escapeHtml(ev.name) + '</div>'
      + '<div class="count">' + active + ' active / ' + total + ' competitions</div>'
      + '</div>'
      + '<div class="arrow">›</div>'
      + '</div>';
  }
  html += '</div>';
  if (events.length === 0) {
    html = '<p class="text-muted text-center" style="padding:48px 0;">No events yet.'
      + (isAdmin() ? ' <button class="btn btn-sm btn-secondary" onclick="createEventFromHome()">Create your first event</button>' : '')
      + '</p>';
  }
  if (container) container.innerHTML = html;
  showScreen('screen-home', true);
  showScreen('screen-setup', false);
  showScreen('screen-groups', false);
  showScreen('screen-fixtures', false);
  showScreen('screen-knockout', false);
  showScreen('screen-champion', false);
  showScreen('screen-results', false);
  if (!isAdmin()) applyViewerMode();
}


// ===================== BREADCRUMB =====================
function renderBreadcrumb() {
  var bc = document.getElementById('breadcrumb');
  if (!bc) return;
  bc.classList.remove('hidden');
  if (AppState.view === 'home') {
    bc.innerHTML = '<span class="bc-item bc-current" onclick="goHome()">Home</span>';
    return;
  }
  var parts = ['<span class="bc-item" onclick="goHome()">Home</span>'];
  if (AppState.view === 'event') {
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item bc-current" onclick="goToEventPage()">' + escapeHtml(AppState.event) + '</span>');
  } else if (AppState.view === 'sport') {
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item" onclick="goToEventPage()">' + escapeHtml(AppState.event) + '</span>');
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item bc-current" onclick="goToSportPage()">' + sportLabel(AppState.sport) + '</span>');
  } else {
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item" onclick="goToEventPage()">' + escapeHtml(AppState.event) + '</span>');
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item" onclick="goToSportPage()">' + sportLabel(AppState.sport) + '</span>');
    parts.push('<span class="bc-sep">›</span>');
    parts.push('<span class="bc-item bc-current" onclick="renderAll()">' + escapeHtml(getCategoryLabel()) + '</span>');
  }
  bc.innerHTML = parts.join('');
}

function updateNavigationVisibility() {
  var catBar = document.getElementById('catBar');
  var tournamentTabs = document.getElementById('tournamentTabs');
  var actionBar = document.getElementById('actionBar');
  var view = AppState.view;
  var showingResults = AppState.ui.showingResults;
  var isOverview = view === 'home' || view === 'event' || view === 'sport' || view === 'results' || showingResults;
  var isTournamentView = !isOverview;

  if (catBar) catBar.style.display = isTournamentView ? '' : 'none';
  if (actionBar) actionBar.style.display = isTournamentView ? '' : 'none';
  if (tournamentTabs) tournamentTabs.classList.toggle('hidden', isOverview || view === 'setup');
}

function getCategoryLabel() {
  var tmpl = getTemplates().find(function(t) { return t.id === AppState.category; });
  return tmpl ? tmpl.name : (AppState.category || 'Tournament');
}

// ===================== EVENT / SPORT PAGES =====================
function goToEventPage(ev) {
  if (ev) AppState.event = ev;
  navigateTo('event');
}

function goToSportPage(ev, sport) {
  if (ev) AppState.event = ev;
  if (sport) AppState.sport = sport;
  navigateTo('sport');
}

function renderEventPage() {
  clearDisabled();
  updateHeader();
  var container = document.getElementById('eventContent');
  var cats = getCategories().filter(function(c) { return c.event === AppState.event; });
  var html = '<h2 class="page-title">' + escapeHtml(AppState.event) + '</h2>';
  if (cats.length === 0) {
    html += '<p class="text-muted text-center" style="padding:48px 0;">No competitions in this event.</p>';
  } else {
    html += '<div class="home-sport-grid">';
    for (var i = 0; i < cats.length; i++) {
      var c = cats[i];
      var st = localLoad(c.id);
      var phase = st ? st.phase : 'setup';
      var statusIcon = phase === 'setup' ? '⚪' : phase === 'champion' ? '🏆' : '🟢';
      var statusLabel = phase === 'setup' ? 'Not Started' : phase === 'champion' ? 'Complete' : 'In Progress';
      var count = st && st.participants ? st.participants.length : 0;
      var countLabel = c.type === 'doubles' ? 'teams' : 'players';
      html += '<div class="home-sport-card" onclick="switchCategory(\'' + c.id + '\')">'
        + '<div class="home-sport-icon">' + getSportIcon(c.sport) + '</div>'
        + '<div class="home-sport-info">'
        + '<div class="name">' + escapeHtml(c.label) + '</div>'
        + '<div class="count">' + statusIcon + ' ' + statusLabel + (count > 0 ? ' &middot; ' + count + ' ' + countLabel : '') + '</div>'
        + '</div>'
        + '<div class="arrow">›</div></div>';
    }
    html += '</div>';
  }
  // Template management (admin only)
  if (isAdmin()) {
    const ev = getEvents().find(function(e) { return e.name === AppState.event; });
    const templates = getTemplates();
    const evTemplates = templates.filter(function(t) { return ev && ev.templateIds.indexOf(t.id) !== -1; });
    html += '<div style="margin-top:24px;padding-top:16px;border-top:1px solid var(--border);">'
      + '<h3 style="font-size:.9rem;margin-bottom:8px;">Competitions in this Event</h3>'
      + '<div id="eventTemplateList" style="margin-bottom:8px;">';
    for (var ti = 0; ti < evTemplates.length; ti++) {
      var t = evTemplates[ti];
      html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border);font-size:.85rem;">'
        + '<span>' + escapeHtml(t.name) + ' <span style="font-size:.7rem;color:var(--text-muted);">(' + getSportLabel(t.sport) + ', ' + t.type + ')</span></span>'
        + '<button class="btn btn-outline btn-sm" style="font-size:.7rem;padding:2px 8px;border-color:#dc2626;color:#dc2626;" onclick="toggleConfirmRemoveFromEvent(\'' + t.id + '\')">✕</button>'
        + '</div>'
        + '<div id="confirmRemoveFromEvent_' + t.id + '" class="hidden" style="margin-top:4px;margin-bottom:6px;background:#fef2f2;border:1px solid #fecaca;border-radius:6px;padding:6px 8px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;">'
        + '<span style="font-size:.7rem;color:#dc2626;font-weight:500;">Type REMOVE:</span>'
        + '<input type="text" id="confirmRemoveFromEventInput_' + t.id + '" style="flex:1;min-width:80px;padding:3px 6px;border:2px solid #fecaca;border-radius:6px;font-size:.75rem;" placeholder="REMOVE">'
        + '<button class="btn" style="padding:3px 8px;font-size:.7rem;background:#dc2626;" onclick="executeRemoveFromEvent(\'' + t.id + '\')">Go</button></div>';
    }
    html += '</div>'
      + '<div class="form-row" style="margin-top:8px;">'
      + '<div class="form-field"><label class="form-label">Label</label><input type="text" id="newTemplateLabel" class="form-input" placeholder="e.g. Junior" style="font-size:.8rem;"></div>'
      + '<div class="form-field"><label class="form-label">Sport</label><select id="newTemplateSport" class="form-input" style="font-size:.8rem;"><option value="badminton">Badminton</option><option value="tableTennis">Table Tennis</option><option value="chess">Chess</option></select></div>'
      + '<div class="form-field"><label class="form-label">Format</label><select id="newTemplateType" class="form-input" style="font-size:.8rem;"><option value="singles">Singles</option><option value="doubles">Doubles</option></select></div>'
      + '<div style="display:flex;align-items:flex-end;"><button class="btn btn-sm" onclick="addTemplateToCurrentEvent()" style="font-size:.8rem;">Add</button></div>'
      + '</div>'
      + '<span id="eventTemplateError" style="font-size:.75rem;color:#dc2626;display:block;margin-top:4px;"></span>'
      + '</div>';
  }
  if (container) container.innerHTML = html;
  showScreen('screen-event', true);
  showScreen('screen-sport', false);
  showScreen('screen-home', false);
  showScreen('screen-setup', false);
  showScreen('screen-groups', false);
  showScreen('screen-fixtures', false);
  showScreen('screen-knockout', false);
  showScreen('screen-champion', false);
  showScreen('screen-results', false);
  updateNavigationVisibility();
  if (!isAdmin()) applyViewerMode();
}

function renderSportPage() {
  clearDisabled();
  updateHeader();
  var container = document.getElementById('sportContent');
  var ev = getEvents().find(function(e) { return e.name === AppState.event; });
  var templates = getTemplates();
  var evTemplates = ev ? templates.filter(function(t) { return ev.templateIds.indexOf(t.id) !== -1 && t.sport === AppState.sport; }) : [];
  var html = '<h2 class="page-title">' + sportLabel(AppState.sport) + '</h2>';
  if (evTemplates.length === 0) {
    html += '<p class="text-muted text-center" style="padding:48px 0;">No competitions in this sport.</p>';
  } else {
    for (var i = 0; i < evTemplates.length; i++) {
      var t = evTemplates[i];
      var s = localLoad(t.id);
      var dot = 'setup';
      var statusText = '⚪ Not Started';
      if (s) {
        if (s.phase === 'champion') { dot = 'done'; statusText = '🏆 Complete'; }
        else if (s.phase !== 'setup') { dot = 'playing'; statusText = '🟢 In Progress'; }
      }
      var fmt = t.type || 'singles';
      var isDoubles = fmt === 'doubles';
      var countLabel = isDoubles ? ' Teams' : ' Players';
      var participantCount = (s && s.participants) ? s.participants.length : 0;
      html += '<div class="category-card" onclick="switchCategory(\'' + t.id + '\')">'
        + '<div class="cat-card-left"><span class="dot ' + dot + '"></span>'
        + '<span class="cat-card-name">' + escapeHtml(t.name) + '</span></div>'
        + '<div class="cat-card-right"><span class="cat-card-count">' + participantCount + countLabel + '</span>'
        + '<span class="cat-card-format">' + fmt + '</span>'
        + '<span class="cat-card-status ' + dot + '">' + statusText + '</span></div></div>';
    }
  }
  if (container) container.innerHTML = html;
  showScreen('screen-sport', true);
  showScreen('screen-event', false);
  showScreen('screen-home', false);
  showScreen('screen-setup', false);
  showScreen('screen-groups', false);
  showScreen('screen-fixtures', false);
  showScreen('screen-knockout', false);
  showScreen('screen-champion', false);
  showScreen('screen-results', false);
  updateNavigationVisibility();
  if (!isAdmin()) applyViewerMode();
}

// ===================== TOURNAMENT TABS =====================
function switchTab(tab) {
  if (tab === 'groups') { goToGroups(); return; }
  if (tab === 'fixtures') { goToFixtures(); return; }
  if (tab === 'knockout') { viewKnockout(); return; }
  if (tab === 'champion') { viewChampion(); return; }
}

function navigateToSport(ev, sport) {
  AppState.event = ev;
  AppState.sport = sport;
  goToSportPage(ev, sport);
}

// ===================== RENDER CYCLE =====================
function renderAll() {
  AppState.ui.showingResults = false;
  clearDisabled();

  renderBreadcrumb();
  renderSportBar();
  renderEventBar();

  if (AppState.view === 'home') {
    renderHomePage();
    return;
  }

  // Event / Sport pages
  if (AppState.view === 'event') { renderEventPage(); return; }
  if (AppState.view === 'sport') { renderSportPage(); return; }

  // Tournament view
  updateNavigationVisibility();

  // Tournament tabs
  // Tab button visibility (overall tabs visibility handled by updateNavigationVisibility)
  var _tb = document.getElementById('tournamentTabs');
  if (_tb && AppState.tournament) {
    document.querySelectorAll('.tab-btn').forEach(function(b) {
      b.classList.toggle('active', b.dataset.tab === AppState.view);
      var tab = b.dataset.tab;
      if (tab === 'groups' || tab === 'fixtures') {
        b.classList.toggle('hidden', AppState.tournament.phase === 'setup');
      } else {
        b.classList.toggle('hidden', AppState.tournament.phase !== 'knockout' && AppState.tournament.phase !== 'champion');
      }
    });
  }

  if (!isAdmin() && AppState.tournament && AppState.tournament.phase === 'setup') {
    const ev = getEvents().find(function(e) { return e.name === AppState.event; });
    const templates = getTemplates();
    let foundTmpl = null;
    if (ev) {
      for (const tmplId of ev.templateIds) {
        const tmpl = templates.find(function(t) { return t.id === tmplId && t.sport === AppState.sport; });
        if (!tmpl) continue;
        if (tmpl.id === AppState.category) continue;
        const s = localLoad(tmpl.id);
        if (s && s.phase !== 'setup') { foundTmpl = tmpl.id; break; }
      }
    }
    if (foundTmpl) {
      AppState.category = foundTmpl;
      AppState.tournament = localLoad(foundTmpl) || defaultState();
      navigateTo(AppState.tournament.phase);
      return;
    }
    renderCategoryBar();
    updateHeader();
    var _ab = document.getElementById('actionBar'); if (_ab) _ab.style.display = 'none';
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('screen-results').classList.add('active');
    document.getElementById('resultsList').innerHTML = '<p class="text-muted text-center" style="padding:48px 0;">No active tournaments yet.</p>';
    if (!isAdmin()) applyViewerMode();
    return;
  }

  if (!AppState.tournament) { AppState.tournament = defaultState(); }
  renderCategoryBar();
  updateHeader();
  renderActionBar();
  // Sync knockout buttons in action bar
  if (AppState.view === 'knockout' && AppState.tournament.knockout) {
    var _finalMatch = AppState.tournament.knockout.find(function(mm) { return mm.id === 'final'; });
    var _finalDone = _finalMatch && _finalMatch.done;
    var _ab1 = document.getElementById('actionBarShowResults');
    var _ab2 = document.getElementById('actionBarViewChampion');
    if (_ab1) _ab1.classList.toggle('hidden', !(_finalDone && isAdmin()));
    if (_ab2) _ab2.classList.toggle('hidden', !_finalDone);
  }
  showScreen('screen-setup', AppState.view === 'setup');
  showScreen('screen-groups', AppState.view === 'groups');
  showScreen('screen-fixtures', AppState.view === 'fixtures');
  showScreen('screen-knockout', AppState.view === 'knockout');
  showScreen('screen-champion', AppState.view === 'champion');
  showScreen('screen-event', false);
  showScreen('screen-sport', false);
  showScreen('screen-home', false);
  showScreen('screen-results', false);
  if (AppState.view === 'setup') renderSetup();
  if (AppState.view === 'groups') renderGroups();
  if (AppState.view === 'fixtures') renderFixtures();
  if (AppState.view === 'knockout') renderKnockout();
  if (AppState.view === 'champion') renderChampion();
  if (!isAdmin()) applyViewerMode();
}

function clearDisabled() {
  if (isAdmin()) document.body.classList.remove('viewer-mode');
  const app = document.getElementById('app');
  app.querySelectorAll('input, button, select').forEach(el => {
    if (el.type === 'file') { el.disabled = false; return; }
    el.style.display = '';
    el.disabled = false;
  });
  app.querySelectorAll('.photo-zone').forEach(el => {
    el.style.pointerEvents = '';
    el.style.cursor = '';
  });
  app.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
}

function applyViewerMode() {
  document.body.classList.add('viewer-mode');
  document.querySelectorAll('.photo-zone').forEach(el => {
    el.style.pointerEvents = 'none';
    el.style.cursor = 'default';
  });
}

function showScreen(id, show) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('active', show);
}

// ===================== NAVIGATION =====================
function navigateTo(view) {
  AppState.view = view;
  renderAll();
}

function viewKnockout() {
  navigateTo('knockout');
}

function goToGroups() {
  navigateTo('groups');
}

function goToFixtures() {
  const result = computeStandings(AppState.tournament.groups, AppState.tournament.fixtures, AppState.tournament.participants);
  AppState.tournament.standings = result.standings;
  AppState.tournament.qualifiers = result.qualifiers;
  navigateTo('fixtures');
}

function goToKnockout() {
  if (!isAdmin()) return;
  AppState.tournament.phase = 'knockout';
  AppState.tournament.knockout = advanceWinner(AppState.tournament.knockout);
  saveState();
  navigateTo('knockout');
}

function goToFixturesFromKnockout() {
  const result = computeStandings(AppState.tournament.groups, AppState.tournament.fixtures, AppState.tournament.participants);
  AppState.tournament.standings = result.standings;
  AppState.tournament.qualifiers = result.qualifiers;
  navigateTo('fixtures');
}

function goBackFromChampion() {
  navigateTo('knockout');
}

// ===================== RESULTS PAGE =====================
function showResultsPage() {
  AppState.ui.showingResults = true;
  renderBreadcrumb();
  updateNavigationVisibility();
  renderCategoryBar();
  updateHeader();
  var _sh = document.getElementById('screen-home'); if (_sh) _sh.classList.remove('active');
  document.getElementById('screen-results').classList.add('active');
  document.querySelectorAll('.screen:not(#screen-results)').forEach(s => { if (s.id !== 'screen-home') s.classList.remove('active'); });
  renderResults();
  applyViewerMode();
  document.querySelectorAll('.admin-only').forEach(el => el.classList.add('hidden'));
}

function closeResults() {
  AppState.ui.showingResults = false;
  document.getElementById('screen-results').classList.remove('active');
  renderAll();
}

function renderResults() {
  clearDisabled();
  const templates = getTemplates();
  const events = getEvents();
  const roundLabel = { 'QF': 'Quarter Final', 'SF': 'Semi Final', 'Final': 'Final' };
  const container = document.getElementById('resultsList');
  let html = '';
  let hasContent = false;
  for (const ev of events) {
    const evMatchData = [];
    const evChampions = [];
    for (const tmplId of ev.templateIds) {
      const tmpl = templates.find(t => t.id === tmplId);
      if (!tmpl) continue;
      const s = localLoad(tmpl.id);
      if (!s || (s.phase !== 'knockout' && s.phase !== 'champion') || !s.knockout) continue;
      hasContent = true;
      for (const m of s.knockout) {
        const _participants = s.participants;
        const resolve = function(id) { return _participants ? participantName(_participants, id) || id || 'TBD' : id || 'TBD'; };
        const p1 = resolve(m.p1);
        const p2 = resolve(m.p2);
        const winnerName = resolve(m.winner);
        let score = '';
        if (m.round === 'Final' && m.sets) {
          const parts = [];
          for (const set of m.sets) {
            if (set.s1 !== null && set.s2 !== null) parts.push(set.s1 + '-' + set.s2);
          }
          score = parts.join(' / ');
        } else if (m.s1 !== null && m.s2 !== null) {
          score = m.s1 + '-' + m.s2;
        }
        evMatchData.push({
          catLabel: tmpl.name,
          round: roundLabel[m.round] || m.round,
          p1: p1, p2: p2,
          score: score || '—',
          done: m.done,
          winner: winnerName,
          updatedAt: m.updatedAt || 0
        });
      }
      const _final = s.knockout.find(m => m.id === 'final');
      if (_final && _final.done && _final.winner) {
        const chId = _final.winner;
        const ruId = _final.winner === _final.p1 ? _final.p2 : _final.p1;
        const chName = s.participants ? participantName(s.participants, chId) || chId : chId;
        const ruName = s.participants ? participantName(s.participants, ruId) || ruId || '—' : ruId || '—';
        evChampions.push({ catLabel: tmpl.name, champion: chName, runnerUp: ruName, championPhoto: s.championPhoto, runnerUpPhoto: s.runnerUpPhoto });
      }
    }
    if (evChampions.length === 0 && evMatchData.length === 0) continue;
    html += '<div class="home-event"><h2>' + escapeHtml(ev.name) + '</h2>';
    if (evChampions.length > 0) {
      html += '<div class="results-cards">';
      for (const c of evChampions) {
        html += '<div class="champion-card">'
          + '<div class="trophy">🏆</div>'
          + '<div class="crown">' + escapeHtml(c.catLabel) + '</div>'
          + '<div class="name">' + escapeHtml(c.champion) + '</div>'
          + (c.championPhoto ? '<img src="' + c.championPhoto + '" class="champion-photo">' : '')
          + '<div class="runner-up">Runner-up: <strong>' + escapeHtml(c.runnerUp) + '</strong></div>'
          + (c.runnerUpPhoto ? '<img src="' + c.runnerUpPhoto + '" class="runnerup-photo">' : '')
          + '</div>';
      }
      html += '</div>';
    }
    if (evMatchData.length > 0) {
      evMatchData.sort((a, b) => b.updatedAt - a.updatedAt);
      html += '<div class="results-cards">';
      for (const m of evMatchData) {
        const status = m.done ? '<span class="match-status-done">\u2713 ' + escapeHtml(m.winner) + '</span>' : '<span class="match-status-pending">\u23F3 Upcoming</span>';
        html += '<div class="result-card' + (m.done ? ' result-done' : '') + '">'
          + '<div class="result-card-header">'
          + '<span class="result-cat">' + escapeHtml(m.catLabel) + '</span>'
          + '<span class="result-round">' + m.round + '</span>'
          + '</div>'
          + '<div class="result-match">' + escapeHtml(m.p1) + ' <span class="vs">vs</span> ' + escapeHtml(m.p2) + '</div>'
          + '<div class="result-score">' + escapeHtml(m.score) + '</div>'
          + '<div class="result-status">' + status + '</div>'
          + '</div>';
      }
      html += '</div>';
    }
    html += '</div>';
  }
  if (!hasContent) {
    html += '<p class="text-muted text-center" style="padding:32px 0;">No knockout matches yet.</p>';
  }
  container.innerHTML = html;
}

// ===================== INIT =====================
async function init() {
  on('userLoggedIn', function() { updateBanners(); renderAll(); });
  on('userLoggedOut', function() { navigateTo(AppState.tournament.phase); });

  initSupabase();

  // Metadata (templates + events) from Supabase first, fallback to localStorage
  if (_supabase) {
    await checkSession();
    const meta = await fetchMetadataFromCloud().catch(() => null);
    if (meta) {
      if (meta.templates && meta.events) {
        saveTemplates(meta.templates);
        saveEvents(meta.events);
      } else if (meta.categories) {
        saveCategories(meta.categories);
      }
    }
  }

  runMigration();

  // Sync metadata to cloud
  if (_supabase && isAdmin()) {
    syncMetadataToCloud();
  }

  try {
    const old = localStorage.getItem('btm_state');
    if (old && !localStorage.getItem('btm_state_senior_boys')) {
      localStorage.setItem('btm_state_senior_boys', old);
    }
    localStorage.removeItem('btm_state');
  } catch(e) {}

  // Migrate old-format state to participant IDs
  for (const cat of getCategories()) {
    const s = localLoad(cat.id);
    if (s && s.players && !s.participants) {
      const nameToId = {};
      s.participants = s.players.map((n, i) => {
        const p = createParticipant(n);
        nameToId[n] = p.id;
        return p;
      });
      if (s.groups) {
        for (const key of Object.keys(s.groups)) {
          s.groups[key] = s.groups[key].map(name => nameToId[name] || name);
        }
      }
      if (s.fixtures) {
        for (const f of s.fixtures) {
          if (f.p1) f.p1 = nameToId[f.p1] || f.p1;
          if (f.p2) f.p2 = nameToId[f.p2] || f.p2;
        }
      }
      if (s.knockout) {
        for (const m of s.knockout) {
          if (m.p1) m.p1 = nameToId[m.p1] || m.p1;
          if (m.p2) m.p2 = nameToId[m.p2] || m.p2;
          if (m.winner) m.winner = nameToId[m.winner] || m.winner;
        }
      }
      if (s.standings) {
        for (const key of Object.keys(s.standings)) {
          for (const r of s.standings[key]) {
            r.id = nameToId[r.name] || r.name;
          }
        }
      }
      if (s.qualifiers) {
        for (const q of s.qualifiers) {
          q.id = nameToId[q.id] || q.id;
        }
      }
      if (s.champion) s.champion = nameToId[s.champion] || s.champion;
      if (s.runnerUp) s.runnerUp = nameToId[s.runnerUp] || s.runnerUp;
      localSave(cat.id, s);
    }
  }

  // Prep: sync category states from Supabase, then pick starting category
  if (_supabase) {
    for (const cat of getCategories()) {
      const s = await fetchState(cat.id).catch(() => null);
      if (s && s._lastSave > ((localLoad(cat.id) || {})._lastSave || 0)) {
        localSave(cat.id, s);
      }
    }
    subscribeToChanges();
    subscribeToMetadataChanges();
    updateBanners();
  }

  let startCat = null;
  for (const cat of getCategories()) {
    const s = localLoad(cat.id);
    if (s && s.phase !== 'setup') { startCat = cat.id; break; }
  }
  const firstCat = getCategories()[0];
  if (firstCat) {
    if (firstCat.sport) AppState.sport = firstCat.sport;
    if (firstCat.event) AppState.event = firstCat.event;
  }
  AppState.category = startCat || (firstCat ? firstCat.id : null);
  const saved = localLoad(AppState.category);
  if (saved && saved.phase !== 'setup') {
    AppState.tournament = saved;
  } else {
    AppState.tournament = defaultState();
  }

  // Supabase-first for current category state
  if (_supabase) {
    const serverState = await fetchState(AppState.category).catch(() => null);
    if (serverState && serverState._lastSave > (AppState.tournament._lastSave || 0)) {
      AppState.tournament = serverState;
      localSave(AppState.category, AppState.tournament);
    }
  }

  if (location.search.includes('admin')) {
    const link = document.getElementById('adminFooterLink');
    if (link) link.classList.remove('hidden');
  }

  navigateTo('home');
}

document.addEventListener('DOMContentLoaded', function() { init(); });
